import{default as t}from"../components/error.svelte-e0caaeb5.js";export{t as component};
