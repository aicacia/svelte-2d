import{default as t}from"../components/error.svelte-cea44a1c.js";export{t as component};
