import{default as t}from"../components/pages/(scenes)/math/_page.svelte-cfbe339c.js";export{t as component};
