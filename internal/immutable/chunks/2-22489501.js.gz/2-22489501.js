import{default as r}from"../components/pages/_page.svelte-3a1119f9.js";import"./index-9421c6de.js";import"./Scene-938c8aa7.js";export{r as component};
