import{default as t}from"../components/error.svelte-d8a70905.js";export{t as component};
