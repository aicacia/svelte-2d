import{default as t}from"../components/pages/_page.svelte-ad69b24d.js";export{t as component};
