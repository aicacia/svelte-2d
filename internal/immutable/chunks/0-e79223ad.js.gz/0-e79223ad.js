import{default as r}from"../components/pages/_layout.svelte-116f3795.js";import"./index-9421c6de.js";import"./Scene-938c8aa7.js";export{r as component};
