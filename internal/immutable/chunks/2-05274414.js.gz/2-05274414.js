import{default as t}from"../components/pages/(scenes)/_layout.svelte-b09918e5.js";export{t as component};
