import{default as t}from"../components/pages/_page.svelte-93bc11c2.js";export{t as component};
