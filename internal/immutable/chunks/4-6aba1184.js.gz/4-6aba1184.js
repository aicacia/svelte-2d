import{default as t}from"../components/pages/(scenes)/dag/_page.svelte-2cc6cc5e.js";export{t as component};
