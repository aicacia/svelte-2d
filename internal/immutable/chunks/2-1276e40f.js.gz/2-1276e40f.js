import{default as t}from"../components/pages/_page.svelte-bf1a0e2e.js";export{t as component};
