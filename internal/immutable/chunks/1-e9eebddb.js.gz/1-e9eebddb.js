import{default as t}from"../components/error.svelte-bdcf74df.js";export{t as component};
