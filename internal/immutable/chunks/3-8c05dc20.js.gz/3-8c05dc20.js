import{default as t}from"../components/pages/_page.svelte-17652aa9.js";export{t as component};
