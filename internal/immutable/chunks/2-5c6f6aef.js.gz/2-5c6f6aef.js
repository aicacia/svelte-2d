import{default as t}from"../components/pages/_page.svelte-6c28d868.js";export{t as component};
