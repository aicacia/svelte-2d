import{default as r}from"../components/error.svelte-7a445892.js";import"./index-9421c6de.js";import"./singletons-35f37d91.js";export{r as component};
